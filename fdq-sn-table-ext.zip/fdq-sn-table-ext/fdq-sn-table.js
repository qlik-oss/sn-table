define(['./dist/fdq-sn-table'], (supernova) => supernova);
